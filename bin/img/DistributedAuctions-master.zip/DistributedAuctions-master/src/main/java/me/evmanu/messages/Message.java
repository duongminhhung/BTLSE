package me.evmanu.messages;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public final class Message {

    private final MessageContent content;

}
