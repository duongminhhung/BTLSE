package me.evmanu.messages;

public class MessageStandards {

    public static final String MESSAGE_TYPE_NAME = "MESSAGE_TYPE";

    public static final String BLOCK_TYPE = "BLOCK_TYPE";

    public static final String DATA_NAME = "DATA";

}
