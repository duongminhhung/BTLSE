package me.evmanu.p2p.nodeoperations;

public enum NodeOperationState {

    NOT_ASKED,
    WAITING_RESPONSE,
    RESPONDED,
    FAILED;

}
