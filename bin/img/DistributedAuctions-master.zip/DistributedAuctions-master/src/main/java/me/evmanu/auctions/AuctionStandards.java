package me.evmanu.auctions;

public class AuctionStandards {

    /**
     * The amount of blocks to expire a pending payment of a
     */
    public static final int PAYMENT_EXPIRATION_BLOCKS = 5;

}
