package me.evmanu.messages;

public abstract class MessageContent {

    public abstract MessageType getType();

}
