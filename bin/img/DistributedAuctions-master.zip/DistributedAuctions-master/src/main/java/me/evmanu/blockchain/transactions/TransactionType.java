package me.evmanu.blockchain.transactions;

public enum TransactionType {

    TRANSACTION,
    STAKE,
    STAKE_WITHDRAWAL,
    MINING_REWARD

}
